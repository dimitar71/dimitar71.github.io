package com.dimitargenov.yelp.ui.search;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.OnScrollListener;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.RadioGroup;
import android.widget.TextView;
import com.dimitargenov.yelp.Application;
import com.dimitargenov.yelp.R;
import com.dimitargenov.yelp.data.yelp.Business;
import com.dimitargenov.yelp.data.yelp.search.SearchManager.RequestBuilder;
import com.dimitargenov.yelp.util.Networks;
import com.dimitargenov.yelp.util.Views;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import rx.Subscriber;
import rx.android.schedulers.AndroidSchedulers;
import rx.schedulers.Schedulers;

public final class Search extends Fragment {
	public static final String NAME = Search.class.getSimpleName();

	private static final String ADAPTER_MODELS_KEY = "adapterModelsKey";
	private static final String SEARCH_WHAT_KEY = "searchWhatKey";
	private static final String SEARCH_WHERE_KEY = "searchWhereKey";
	private static final String SEARCH_SORTBY_KEY = "searchSortByKey";
	@NonNull
	GridLayoutManager gridLayoutManager;
	// preventing user to abuse click events and do damage with remote calls
	private long searchLastClickTimestamp;
	private Toolbar toolbar;
	private TextView searchWhat;
	private TextView searchWhere;
	private RadioGroup searchSortBy;
	private final TextWatcher onSearchTextChangedListener = new TextWatcher() {
		@Override
		public void beforeTextChanged(final CharSequence s, final int start, final int count, final int after) {}

		@Override
		public void onTextChanged(final CharSequence s, final int start, final int before, final int count) {}

		@Override
		public void afterTextChanged(final Editable s) {
			String what = searchWhat.getText() != null ? searchWhat.getText().toString().trim() : "";
			String where = searchWhere.getText() != null ? searchWhere.getText().toString().trim() : "";
			int searchSortByVisibility = !TextUtils.isEmpty(what) && !TextUtils.isEmpty(where) ? View.VISIBLE : View.GONE;
			searchSortBy.setVisibility(searchSortByVisibility);

			recyclerView.setPadding(recyclerView.getPaddingLeft(), toolbar.getHeight(), recyclerView.getPaddingRight(),
				recyclerView.getPaddingBottom());
		}
	};
	private RecyclerView recyclerView;
	@Nullable
	private List<AdapterModel> adapterModels;

	private boolean isUpdating;

	@Nullable
	@Override
	public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
		return inflater.inflate(R.layout.search, container, false);
	}

	@Override
	public void onViewCreated(final View view, final Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);

		Resources resources = getResources();
		final int columnsInLandscape = resources.getInteger(R.integer.search_columns_landscape);

		int columns = resources.getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE ? columnsInLandscape
			: 1;

		toolbar = (Toolbar) view.findViewById(R.id.toolbar);
		searchWhat = (TextView) toolbar.findViewById(R.id.searchWhat);
		searchWhat.addTextChangedListener(onSearchTextChangedListener);
		searchWhere = (TextView) toolbar.findViewById(R.id.searchWhere);
		searchWhere.addTextChangedListener(onSearchTextChangedListener);
		searchSortBy = (RadioGroup) toolbar.findViewById(R.id.searchSortBy);
		toolbar.findViewById(R.id.search).setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(final View v) {
				long now = System.currentTimeMillis();
				if (now - searchLastClickTimestamp < Application.TIME_BETWEEN_CLICK) {
					return;
				}
				searchLastClickTimestamp = now;
				load(true);
			}
		});
		toolbar.getViewTreeObserver().addOnGlobalLayoutListener(new OnGlobalLayoutListener() {
			@Override
			public void onGlobalLayout() {
				if (toolbar.getViewTreeObserver() != null) {
					toolbar.getViewTreeObserver().removeOnGlobalLayoutListener(this);
				}

				recyclerView.setPadding(recyclerView.getPaddingLeft(), toolbar.getHeight(), recyclerView.getPaddingRight(),
					recyclerView.getPaddingBottom());
			}
		});

		gridLayoutManager = new GridLayoutManager(view.getContext(), columns);
		recyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
		recyclerView.setLayoutManager(gridLayoutManager);
		recyclerView.setItemAnimator(new DefaultItemAnimator());
		recyclerView.setHasFixedSize(true);
		recyclerView.addOnScrollListener(new OnScrollListener() {
			@Override
			public void onScrolled(final RecyclerView recyclerView, final int dx, final int dy) {
				super.onScrolled(recyclerView, dx, dy);

				int toolbarHeight = toolbar.getHeight();
				float toolbarTranslationY = toolbar.getTranslationY();
				if (toolbarHeight > 0) {
					if (gridLayoutManager.findFirstVisibleItemPosition() == 0) {
						if (toolbarTranslationY <= toolbarHeight) {
							toolbar.animate().translationY(0).setDuration(50);
							recyclerView.setPadding(recyclerView.getPaddingLeft(), toolbarHeight, recyclerView.getPaddingRight(),
								recyclerView.getPaddingBottom());
						}
					}
					else {
						if (toolbarTranslationY == 0) {
							toolbar.animate().translationY(-toolbarHeight).setDuration(100);
							recyclerView.setPadding(recyclerView.getPaddingLeft(), 0, recyclerView.getPaddingRight(),
								recyclerView.getPaddingBottom());
						}
					}
				}
			}
		});

		if (savedInstanceState != null && savedInstanceState.containsKey(NAME)) {
			Bundle bundle = savedInstanceState.getBundle(NAME);
			if (bundle != null) {
				searchWhat.setText(bundle.getString(SEARCH_WHAT_KEY, ""));
				searchWhere.setText(bundle.getString(SEARCH_WHERE_KEY, ""));
				searchSortBy.check(bundle.getInt(SEARCH_SORTBY_KEY));

				ArrayList<String> items = bundle.getStringArrayList(ADAPTER_MODELS_KEY);
				if (items != null) {
					adapterModels = new ArrayList<>(items.size());

					for (String item : items) {
						try {
							JSONObject json = new JSONObject(item);
							adapterModels.add(new AdapterModel(json));
						}
						catch (JSONException e) {
							// not interested
							e.printStackTrace();
						}
					}
				}
				else {
					adapterModels = Collections.emptyList();
				}

				recyclerView.setAdapter(new Adapter(getActivity(), adapterModels));
			}
		}
		else {
			searchWhat.setText("Ethiopian");
			searchWhere.setText("Toronto");
		}
	}

	@Override
	public void onSaveInstanceState(final Bundle outState) {
		super.onSaveInstanceState(outState);

		Bundle bundle = new Bundle();
		String what = searchWhat.getText() != null ? searchWhat.getText().toString().trim() : "";
		String where = searchWhere.getText() != null ? searchWhere.getText().toString().trim() : "";

		bundle.putString(SEARCH_WHAT_KEY, what);
		bundle.putString(SEARCH_WHERE_KEY, where);
		bundle.putInt(SEARCH_SORTBY_KEY, searchSortBy.getCheckedRadioButtonId());

		if (adapterModels != null) {
			ArrayList<String> items = new ArrayList<>(adapterModels.size());
			for (AdapterModel adapterModel : adapterModels) {
				items.add(adapterModel.json.toString());
			}
			bundle.putStringArrayList(ADAPTER_MODELS_KEY, items);
		}
		outState.putBundle(NAME, bundle);
	}

	private void load(boolean showSnackbar) {
		Activity activity = getActivity();
		if (!Views.isActivityValid(activity)) {
			return;
		}

		if (Networks.getNetworkInfo(activity) == null) {
			Snackbar.make(toolbar, R.string.app_network_down, Snackbar.LENGTH_LONG).show();
			return;
		}

		String what = searchWhat.getText() != null ? searchWhat.getText().toString() : "";
		String where = searchWhere.getText() != null ? searchWhere.getText().toString() : "";

		if (TextUtils.isEmpty(what) || TextUtils.isEmpty(where)) {
			return;
		}

		if (isUpdating) {
			return;
		}

		isUpdating = true;
		InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(searchWhat.getWindowToken(), 0);
		imm.hideSoftInputFromWindow(searchWhere.getWindowToken(), 0);

		Snackbar snackbar = null;
		if (showSnackbar) {
			snackbar = Snackbar.make(toolbar, R.string.search_updating, Snackbar.LENGTH_INDEFINITE);
			snackbar.show();
		}

		final Snackbar snack = snackbar;

		// find sort by choice
		int radioButtonId = searchSortBy.getCheckedRadioButtonId();
		View radioButton = searchSortBy.findViewById(radioButtonId);
		int sortByIndex = radioButton != null ? searchSortBy.indexOfChild(radioButton) : RequestBuilder.BEST_MATCHED;
		sortByIndex = sortByIndex == RequestBuilder.DISTANCE ? RequestBuilder.DISTANCE
			: sortByIndex == RequestBuilder.HIGHEST_RATED ? RequestBuilder.HIGHEST_RATED : RequestBuilder.BEST_MATCHED;

		Application.data.yelp.search.loadAndGet(0, new RequestBuilder(what, where)
			.countryCode(RequestBuilder.CANADA)
			.sortBy(sortByIndex))
			.subscribeOn(Schedulers.computation())
			.observeOn(AndroidSchedulers.mainThread())
			.subscribe(new Subscriber<List<Business>>() {
				@Override
				public void onCompleted() {
					if (snack != null) {
						snack.dismiss();
					}
					isUpdating = false;
				}

				@Override
				public void onError(final Throwable e) {
					e.printStackTrace();
				}

				@Override
				public void onNext(final List<Business> businesses) {
					Activity activity = getActivity();
					if (!Views.isActivityValid(activity)) {
						return;
					}

					if (businesses != null && businesses.size() > 0) {
						// ad on top then anything else
						adapterModels = new ArrayList<>(businesses.size() + 1);
						int adapterPosition = 0;

						for (Business business : businesses) {
							if (business != null) {
								adapterModels.add(new AdapterModel(R.layout.search_cell, business, adapterPosition));
								adapterPosition++;
							}
						}
					}
					else {
						// add a 'No Data' cell
						adapterModels = new ArrayList<AdapterModel>(1) {{
							add(new AdapterModel(R.layout.search_no_data_cell, null, 0));
						}};
					}

					recyclerView.setAdapter(new Adapter(getActivity(), adapterModels));
					recyclerView.scheduleLayoutAnimation();
				}
			});
	}
}
