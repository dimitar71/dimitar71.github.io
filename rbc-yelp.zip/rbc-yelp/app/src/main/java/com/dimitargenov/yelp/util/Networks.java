package com.dimitargenov.yelp.util;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.Nullable;

public final class Networks {
	/**
	 * @return Available {@link NetworkInfo} or null if nothing
	 */
	@Nullable
	public static NetworkInfo getNetworkInfo(Context context) {
		NetworkInfo networkInfo = null;

		if (context != null) {
			try {
				ConnectivityManager manager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
				if (manager != null) {
					final NetworkInfo info = manager.getActiveNetworkInfo();
					networkInfo = info != null && info.isAvailable() && info.isConnected() ? info : null;
				}
			}
			catch (Exception e) {
				// not interested
				e.printStackTrace();
				networkInfo = null;
			}
		}
		return networkInfo;
	}
}
