package com.dimitargenov.yelp;

import com.bumptech.glide.Glide;
import com.bumptech.glide.GlideBuilder;
import com.bumptech.glide.load.DecodeFormat;
import com.bumptech.glide.load.engine.cache.InternalCacheDiskCacheFactory;
import com.bumptech.glide.load.engine.cache.LruResourceCache;
import com.dimitargenov.yelp.data.yelp.search.SearchManager;
import de.greenrobot.event.EventBus;

public class Application extends android.app.Application {
	// 1 sec. between any clicks
	public static final int TIME_BETWEEN_CLICK = 1000;

	public static final class data {
		public static final class yelp {
			public static final SearchManager search = new SearchManager(BuildConfig.YELP_CONSUMER_KEY,
				BuildConfig.YELP_CONSUMER_SECRET, BuildConfig.YELP_TOKEN, BuildConfig.YELP_TOKEN_SECRET);
		}
	}

	@Override
	public void onCreate() {
		super.onCreate();

		// prepare default EventBus instance
		EventBus.builder()
			.sendNoSubscriberEvent(false)
			.sendSubscriberExceptionEvent(false)
			.installDefaultEventBus();

		Glide.setup(new GlideBuilder(this)
			.setMemoryCache(new LruResourceCache(384 * 1024 * 1024))
			.setDiskCache(new InternalCacheDiskCacheFactory(this, 384 * 1024 * 1024))
			.setDecodeFormat(DecodeFormat.PREFER_RGB_565));
	}
}
