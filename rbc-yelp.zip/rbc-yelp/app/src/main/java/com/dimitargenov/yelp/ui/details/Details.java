package com.dimitargenov.yelp.ui.details;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.app.Fragment;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import com.dimitargenov.yelp.R;
import com.dimitargenov.yelp.data.yelp.Business;
import org.json.JSONException;
import org.json.JSONObject;

public final class Details extends Fragment {
	public static final String NAME = Details.class.getSimpleName();

	private static final String BUSNESS_KEY = "businessKey";

	public static Details newInstance(@NonNull Business business) {
		Bundle bundle = new Bundle();
		bundle.putString(BUSNESS_KEY, business.json.toString());

		Details fragment = new Details();
		fragment.setArguments(bundle);
		return fragment;
	}

	@Nullable
	private Business business;

	@Override
	public Animator onCreateAnimator(int transit, boolean enter, int nextAnim) {
		DisplayMetrics displayMetrics = new DisplayMetrics();
		getActivity().getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

		String translation = "translationY";
		int size = displayMetrics.heightPixels;
		int orientation = getResources().getConfiguration().orientation;

		if (orientation == Configuration.ORIENTATION_LANDSCAPE) {
			translation = "translationX";
			size = displayMetrics.widthPixels;
		}

		Animator sliding;
		if (enter) {
			sliding = ObjectAnimator.ofFloat(this, translation, size, 0.0F);
		}
		else {
			sliding = ObjectAnimator.ofFloat(this, translation, 0, size);
		}
		AnimatorSet animatorSet = new AnimatorSet();
		animatorSet.setDuration(160);
		animatorSet.setInterpolator(new AccelerateInterpolator(1.0F));
		animatorSet.play(sliding);
		return animatorSet;
	}

	@Nullable
	@Override
	public View onCreateView(final LayoutInflater inflater, final ViewGroup container, final Bundle savedInstanceState) {
		return inflater.inflate(R.layout.details, container, false);
	}

	@Override
	public void onViewCreated(final View view, final Bundle savedInstanceState) {
		super.onViewCreated(view, savedInstanceState);

		String businessString = "";

		if (savedInstanceState != null && savedInstanceState.containsKey(BUSNESS_KEY))  {
			businessString = savedInstanceState.getString(BUSNESS_KEY);
		}
		else {
			Bundle arguments = getArguments();
			if (arguments != null) {
				businessString = arguments.getString(BUSNESS_KEY);
			}
		}

		try {
			business = Business.from(new JSONObject(businessString));
		}
		catch(JSONException | IllegalArgumentException e) {
			// TODO show an error
			e.printStackTrace();
		}
	}

	@Override
	public void onSaveInstanceState(final Bundle outState) {
		super.onSaveInstanceState(outState);

		if (business != null) {
			outState.putString(BUSNESS_KEY, business.json.toString());
		}
	}

	@Override
	public void onDestroyView() {
		super.onDestroyView();
	}
}
