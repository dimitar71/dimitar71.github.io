package com.dimitargenov.yelp;

import android.app.Fragment;
import android.app.FragmentManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import com.dimitargenov.yelp.ui.details.Details;
import com.dimitargenov.yelp.ui.search.OnCellClickEvent;
import com.dimitargenov.yelp.ui.search.Search;
import com.dimitargenov.yelp.util.Views;
import de.greenrobot.event.EventBus;
import de.greenrobot.event.Subscribe;
import de.greenrobot.event.ThreadMode;

public class ApplicationActivity extends AppCompatActivity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.applicationactivity);

		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
				.add(R.id.applicationActivity, new Search(), Search.NAME)
				.commit();
		}
	}

	@Override
	public void onBackPressed() {
		FragmentManager fragmentManager = getFragmentManager();
		Fragment details = fragmentManager.findFragmentByTag(Details.NAME);
		if (details != null) {
			fragmentManager.popBackStack(Details.NAME, FragmentManager.POP_BACK_STACK_INCLUSIVE);
			return;
		}
		super.onBackPressed();
	}

	@Override
	protected void onStart() {
		super.onStart();

		EventBus.getDefault().register(this);
	}

	@Override
	protected void onStop() {
		super.onStop();

		EventBus.getDefault().unregister(this);
	}

	@Subscribe(threadMode = ThreadMode.MainThread)
	public void onEventBusEvent(@Nullable final OnCellClickEvent event) {
		if (!Views.isActivityValid(this)) {
			return;
		}

		if (event != null && event.business != null) {
			FragmentManager fragmentManager = getFragmentManager();
			fragmentManager.popBackStackImmediate();

			fragmentManager.beginTransaction()
				.add(R.id.applicationActivity, Details.newInstance(event.business), Details.NAME)
				.addToBackStack(Details.NAME)
				.commit();
		}
	}
}