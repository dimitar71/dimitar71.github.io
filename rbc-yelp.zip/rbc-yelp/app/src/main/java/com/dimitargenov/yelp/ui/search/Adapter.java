package com.dimitargenov.yelp.ui.search;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.dimitargenov.yelp.R;
import java.util.List;

class Adapter extends RecyclerView.Adapter {
	@NonNull
	private final LayoutInflater layoutInflater;

	@NonNull
	private final List<AdapterModel> items;

	Adapter(@NonNull Context context, @NonNull List<AdapterModel> items) {
		setHasStableIds(true);

		layoutInflater = LayoutInflater.from(context);
		this.items = items;
	}

	@Override
	public ViewHolder onCreateViewHolder(final ViewGroup parent, final int viewType) {
		View view = layoutInflater.inflate(viewType, parent, false);

		switch (viewType) {
			case R.layout.search_no_data_cell:
				return new ViewHolder(view) {};
			default:
				return new CellViewHolder(view);
		}
	}

	@Override
	public void onBindViewHolder(final ViewHolder holder, final int position) {
		AdapterModel item = items.get(position);

		if (R.layout.search_cell == item.layoutId) {
			// only custom cell holders need data
			((CellViewHolder) holder).update(item);
		}
	}

	@Override
	public int getItemCount() {
		return items.size();
	}

	@Override
	public long getItemId(final int position) {
		return position;
	}

	@Override
	public int getItemViewType(final int position) {
		return items.get(position).layoutId;
	}
}