package com.dimitargenov.yelp.ui.search;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView.ViewHolder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.dimitargenov.yelp.Application;
import com.dimitargenov.yelp.R;
import com.dimitargenov.yelp.data.yelp.Business;
import de.greenrobot.event.EventBus;

final class CellViewHolder extends ViewHolder {
	final ImageView image;
	final TextView rank;
	final TextView name;
	final ImageView stars;
	final TextView reviews;
	final TextView address;
	final TextView categories;
	final TextView expensive;

	@Nullable
	private AdapterModel adapterModel;

	private long lastClickTimestamp;
	private final String reviewsText;

	CellViewHolder(@NonNull View view) {
		super(view);

		view.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(final View v) {
				long now = System.currentTimeMillis();
				if (now - lastClickTimestamp < Application.TIME_BETWEEN_CLICK || adapterModel == null
					|| adapterModel.business == null) {
					return;
				}

				lastClickTimestamp = now;
				EventBus eventBus = EventBus.getDefault();
				if (eventBus.hasSubscriberForEvent(OnCellClickEvent.class)) {
					EventBus.getDefault().post(new OnCellClickEvent(adapterModel.business));
				}
			}
		});

		reviewsText = " " + view.getContext().getString(R.string.search_reviews);

		image = (ImageView) view.findViewById(R.id.image);
		rank = (TextView) view.findViewById(R.id.rank);
		name = (TextView) view.findViewById(R.id.name);
		stars = (ImageView) view.findViewById(R.id.stars);
		reviews = (TextView) view.findViewById(R.id.reviews);
		address = (TextView) view.findViewById(R.id.address);
		categories = (TextView) view.findViewById(R.id.categories);
		expensive = (TextView) view.findViewById(R.id.expensive);
	}

	void update(@Nullable AdapterModel adapterModel) {
		if (adapterModel == null || adapterModel.business == null) {
			return;
		}

		this.adapterModel = adapterModel;
		Business business = this.adapterModel.business;

		Context context = itemView.getContext();

		rank.setText((this.adapterModel.adapterPosition + 1) + ".");
		name.setText(business.name);
		reviews.setText(business.review_count + reviewsText);

		StringBuilder addressBuilder = new StringBuilder();
		for (int i = 0; i < business.display_address.size(); i++) {
			addressBuilder.append(business.display_address.get(i));

			if (i < business.display_address.size() - 1) {
				addressBuilder.append("\n");
			}
		}
		address.setText(addressBuilder.toString());

		StringBuilder categoriesBuilder = new StringBuilder();
		for (int i = 0; i < business.categories.size(); i++) {
			categoriesBuilder.append(business.categories.get(i));

			if (i < business.categories.size() - 1) {
				categoriesBuilder.append(", ");
			}
		}
		categories.setText(categoriesBuilder.toString());

		Glide.with(context)
			.load(business.image_url)
			.error(R.drawable.no_image)
			.dontTransform()
			.dontAnimate()
			.skipMemoryCache(true)
			.diskCacheStrategy(DiskCacheStrategy.RESULT)
			.into(image);

		Glide.with(context)
			.load(business.rating_img_url_large)
			.dontTransform()
			.dontAnimate()
			.skipMemoryCache(true)
			.diskCacheStrategy(DiskCacheStrategy.RESULT)
			.into(stars);
	}
}