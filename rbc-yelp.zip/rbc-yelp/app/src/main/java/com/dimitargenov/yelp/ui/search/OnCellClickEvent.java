package com.dimitargenov.yelp.ui.search;

import android.support.annotation.Nullable;
import com.dimitargenov.yelp.data.yelp.Business;
public final class OnCellClickEvent {
	@Nullable
	public final Business business;

	public OnCellClickEvent(@Nullable Business business) {
		this.business = business;
	}
}
