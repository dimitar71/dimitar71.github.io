package com.dimitargenov.yelp.ui.search;

import android.content.Context;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.GridLayoutAnimationController;

/**
 * Expects only {@link GridLayoutManager}
 */
public class GridLayoutRecyclerView extends RecyclerView {
	public GridLayoutRecyclerView(Context context) {
		this(context, null, 0);
	}

	public GridLayoutRecyclerView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
	}

	public GridLayoutRecyclerView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
	}

	/**
	 *
	 * @param layoutManager layout manager
	 * @throws ClassCastException 'layoutManager' does not derive from GridLayoutManager
	 */
	@Override
	public void setLayoutManager(final LayoutManager layoutManager) throws ClassCastException {
		super.setLayoutManager(layoutManager);

		if (!(layoutManager instanceof GridLayoutManager)) {
			throw new ClassCastException("'layoutManager' does not derive from GridLayoutManager");
		}
	}

	@Override
	protected void attachLayoutAnimationParameters(View child, ViewGroup.LayoutParams params, int index, int count) {
		if (getAdapter() != null) {
			GridLayoutAnimationController.AnimationParameters animationParams =
				(GridLayoutAnimationController.AnimationParameters) params.layoutAnimationParameters;

			if (animationParams == null) {
				animationParams = new GridLayoutAnimationController.AnimationParameters();
				params.layoutAnimationParameters = animationParams;
			}

			int columns = ((GridLayoutManager) getLayoutManager()).getSpanCount();
			animationParams.count = count;
			animationParams.index = index;
			animationParams.columnsCount = columns;
			animationParams.rowsCount = count / columns;

			final int inverted = count - 1 - index;
			animationParams.column = columns - 1 - (inverted % columns);
			animationParams.row = animationParams.rowsCount - 1 - inverted / columns;
		}
		else {
			super.attachLayoutAnimationParameters(child, params, index, count);
		}
	}
}