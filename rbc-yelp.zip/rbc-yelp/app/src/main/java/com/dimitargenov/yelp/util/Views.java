package com.dimitargenov.yelp.util;

import android.app.Activity;
import android.support.annotation.Nullable;

public final class Views {
	public static boolean isActivityValid(@Nullable Activity activity) {
		return activity != null && !activity.isFinishing() && !activity.isDestroyed();
	}
}