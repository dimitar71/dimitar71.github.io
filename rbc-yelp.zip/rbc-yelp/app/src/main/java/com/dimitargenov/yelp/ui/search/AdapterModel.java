package com.dimitargenov.yelp.ui.search;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import com.dimitargenov.yelp.R;
import com.dimitargenov.yelp.data.yelp.Business;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Keeps required for the adapter data as well as {@link Business} instance when 'layoutId' is {@link R.layout#search_cell}
 */
final class AdapterModel {
	@NonNull
	final JSONObject json;
	final int layoutId;

	@Nullable
	final Business business;

	final int adapterPosition;

	AdapterModel(int layoutId, @Nullable Business business, int adapterPosition) {
		this.layoutId = layoutId > 0 ? layoutId : 0;
		this.business = business;
		this.adapterPosition = adapterPosition > 0 ? adapterPosition : 0;

		json = new JSONObject();
		try {
			json.put("layoutId", layoutId);
			json.put("business", business != null ? business.json : new JSONObject());
			json.put("adapterPosition", adapterPosition);
		}
		catch (JSONException e) {
			// not interested
			e.printStackTrace();
		}
	}

	AdapterModel(@NonNull JSONObject json) {
		this.json = json;
		layoutId = this.json.optInt("layoutId");
		adapterPosition = this.json.optInt("adapterPosition");
		Business b = null;
		try {
			JSONObject businessJson = new JSONObject(json.optString("business"));
			b = Business.from(businessJson);
		}
		catch (JSONException | IllegalArgumentException e) {
			// not interested
			e.printStackTrace();
		}

		business = b;
	}
}