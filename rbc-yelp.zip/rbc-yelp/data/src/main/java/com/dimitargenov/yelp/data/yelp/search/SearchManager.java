package com.dimitargenov.yelp.data.yelp.search;

import android.support.annotation.IntDef;
import android.support.annotation.NonNull;
import android.support.annotation.StringDef;
import android.text.TextUtils;
import com.dimitargenov.yelp.data.DataManager;
import com.dimitargenov.yelp.data.oauth.YelpAPI;
import com.dimitargenov.yelp.data.yelp.Business;
import com.dimitargenov.yelp.data.yelp.search.SearchManager.RequestBuilder;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Verb;
import rx.Observable;
import rx.Observable.OnSubscribe;
import rx.Subscriber;
import rx.functions.Func0;

public class SearchManager implements DataManager<Business, RequestBuilder, List<Business>, Integer> {
	private static final String SEARCH_URL = "https://api.yelp.com/v2/search/?actionlinks=true";

	public static class RequestBuilder implements DataManager.RequestBuilder {
		public static final int BEST_MATCHED = 0;
		public static final int DISTANCE = 1;
		public static final int HIGHEST_RATED = 2;
		public static final String USA = "US";
		public static final String CANADA = "CA";
		public static final String ENGLISH = "en";
		public static final String FRENCH = "fr";
		public static final String SPANISH = "es";

		@Retention(RetentionPolicy.SOURCE)
		@IntDef({BEST_MATCHED, DISTANCE, HIGHEST_RATED})
		public @interface SortBy {}

		@Retention(RetentionPolicy.SOURCE)
		@StringDef({USA, CANADA})
		public @interface CountryCode {}

		@Retention(RetentionPolicy.SOURCE)
		@StringDef({ENGLISH, FRENCH, SPANISH})
		public @interface Language {}

		@NonNull
		private final String findWhat;
		@NonNull
		private String location;
		@NonNull
		private String categories;
		@NonNull
		private String sortBy;
		@NonNull
		private String limit;
		@NonNull
		private String radius;
		@NonNull
		private String filterDeals = "";
		@NonNull
		private String countryCode = "";
		@NonNull
		private String language = "";

		/**
		 * @param findWhat find what
		 * @throws IllegalArgumentException 'findWhat' or 'location' is null or empty
		 */
		public RequestBuilder(@NonNull String findWhat, @NonNull String location) throws IllegalArgumentException {
			if (TextUtils.isEmpty(findWhat) || TextUtils.isEmpty(location)) {
				throw new IllegalArgumentException("'findWhat' or 'location' is null or empty");
			}

			this.findWhat = "&term=" + findWhat.trim();
			this.location = "&location=" + location.trim();
			categories = "";
			sortBy = "";
			limit = "";
			radius = "";
		}

		public RequestBuilder categories(@NonNull String category, String... categories) {
			this.categories = "&category_filter=" + category.trim();

			if (categories != null && categories.length > 0) {
				String extra = "";
				for (String c : categories) {
					if (!TextUtils.isEmpty(c)) {
						extra += c.trim() + ",";
					}
				}

				if (!TextUtils.isEmpty(extra)) {
					this.categories += "," + extra.substring(0, extra.length() - 1);
				}
			}

			return this;
		}

		/**
		 * @param sortBy sort by, default: {@link #BEST_MATCHED}
		 * @return this
		 */
		public RequestBuilder sortBy(@SortBy int sortBy) {
			this.sortBy = "&sort=" + sortBy;
			return this;
		}

		public RequestBuilder limit(int limit) {
			limit = limit > -1 ? limit : 10;
			this.limit = "&limit=" + limit;
			return this;
		}

		public RequestBuilder radius(int meters) {
			meters = meters > 0 ? meters : 0;
			this.radius = "&radius_filter=" + meters;
			return this;
		}

		public RequestBuilder filterDeals(boolean filterDeals) {
			this.filterDeals = "&deals_filter=" + filterDeals;
			return this;
		}

		public RequestBuilder countryCode(@CountryCode String countryCode) {
			this.countryCode = "&cc=" + countryCode;
			return this;
		}

		public RequestBuilder language(@Language String language) {
			this.language = "&lang=" + language;
			return this;
		}

		public String build() {
			return SEARCH_URL + findWhat + location + categories + sortBy + limit + radius + filterDeals + countryCode
				+ language;
		}
	}

	@NonNull
	YelpAPI yelpApi;

	/**
	 * @param consumerKey consumer key
	 * @param consumerSecret consumer secret
	 * @param token token
	 * @param tokenSecret token secret
	 * @throws IllegalArgumentException 'consumerKey', 'consumerSecret', 'token' or 'tokenSecret' is null or empty
	 */
	public SearchManager(@NonNull String consumerKey, @NonNull String consumerSecret, @NonNull String token,
		@NonNull String tokenSecret) throws IllegalArgumentException {
		if (TextUtils.isEmpty(consumerKey) || TextUtils.isEmpty(consumerSecret) || TextUtils.isEmpty(token)
			|| TextUtils.isEmpty(tokenSecret)) {
			throw new IllegalArgumentException("'consumerKey', 'consumerSecret', 'token' or 'tokenSecret' is null or empty");
		}

		yelpApi = new YelpAPI(consumerKey.trim(), consumerSecret.trim(), token.trim(), tokenSecret.trim());
	}

	@NonNull
	@Override
	public Observable<List<Business>> get(@NonNull Integer id) {
		return null;
	}

	@NonNull
	@Override
	public Observable<List<Business>> loadAndGet(@NonNull final Integer id, @NonNull final RequestBuilder requestBuilder) {
		return Observable.defer(new Func0<Observable<List<Business>>>() {
			@Override
			public Observable<List<Business>> call() {
				return Observable.create(new OnSubscribe<List<Business>>() {
					@Override
					public void call(final Subscriber<? super List<Business>> subscriber) {
						if (subscriber.isUnsubscribed()) {
							return;
						}

						String url = requestBuilder.build();

						OAuthRequest oAuthRequest = new OAuthRequest(Verb.GET, requestBuilder.build());
						yelpApi.service.signRequest(yelpApi.accessToken, oAuthRequest);
						Response response = oAuthRequest.send();
						String body = response.getBody();

						if (response.isSuccessful() && response.getCode() < 300) {
							List<Business> businesses = Collections.emptyList();

							try {
								JSONObject json = new JSONObject(body);
								JSONArray businessArray = json.optJSONArray("businesses");
								int businessArrayLength = businessArray != null ? businessArray.length() : 0;
								if (businessArrayLength > 0) {
									businesses = new ArrayList<Business>(businessArrayLength);

									for (int i = 0; i < businessArrayLength; i++) {
										try {
											Business business = Business.from(businessArray.optJSONObject(i));
											businesses.add(business);
										}
										catch(IllegalArgumentException e) {
											// not interested
											e.printStackTrace();
										}
									}
								}
							}
							catch(JSONException e) {
								// not interested
								e.printStackTrace();
							}

							subscriber.onNext(businesses);
							subscriber.onCompleted();
						}
						else {
							subscriber.onError(new Exception(body));
						}
					}
				});
			}
		});
	}

	/**
	 * Not implemented
	 */
	@Override
	public void clearDiskCache() {}

	/**
	 * Not implemented
	 */
	@Override
	public void clearMemoryCache() {}
}
