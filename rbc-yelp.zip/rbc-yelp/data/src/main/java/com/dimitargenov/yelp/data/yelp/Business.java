package com.dimitargenov.yelp.data.yelp;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Business DO
 */
public final class Business {
	/**
	 * @param json json
	 * @return new instance
	 * @throws IllegalArgumentException 'json' is null or empty
	 */
	@NonNull
	public static Business from(@Nullable JSONObject json) {
		if (json == null || json.length() == 0) {
			throw new IllegalArgumentException("'json' is null or empty");
		}

		return new Business(json);
	}

	@NonNull
	public final JSONObject json;
	@NonNull
	public final String id;
	@NonNull
	public final String name;
	@NonNull
	public final String rating_img_url_large;
	public final int review_count;
	@NonNull
	public final String city;
	@NonNull
	public final List<String> display_address;
	@NonNull
	public final List<String> categories;
	@NonNull
	public final String image_url;
	@NonNull
	public final String snippet_text;
	@NonNull
	public final String snippet_image_url;
	public final boolean is_closed;

	private Business(@NonNull JSONObject json) {
		this.json = json;
		id = this.json.optString("id", "");
		name = this.json.optString("name", "");
		rating_img_url_large = this.json.optString("rating_img_url_large", "");
		review_count = this.json.optInt("review_count");
		image_url = this.json.optString("image_url", "");
		snippet_text = this.json.optString("snippet_text", "");
		snippet_image_url = this.json.optString("snippet_image_url", "");
		is_closed = this.json.optBoolean("is_closed");

		JSONObject locationJson = this.json.optJSONObject("location");
		locationJson = locationJson != null ? locationJson : new JSONObject();
		city = locationJson.optString("city", "");
		JSONArray displayAddressArray = locationJson.optJSONArray("display_address");
		int displayAddressArrayLength = displayAddressArray != null ? displayAddressArray.length() : 0;
		if (displayAddressArrayLength > 0) {
			display_address = new ArrayList<>(displayAddressArrayLength);

			for (int i = 0; i < displayAddressArrayLength; i++) {
				display_address.add(displayAddressArray.optString(i, ""));
			}
		}
		else {
			display_address = Collections.emptyList();
		}

		JSONArray categoryArray = this.json.optJSONArray("categories");
		int categoryArrayLength = categoryArray != null ? categoryArray.length() : 0;
		if (categoryArrayLength > 0) {
			categories = new ArrayList<>(categoryArrayLength);

			for (int i = 0; i < categoryArrayLength; i++) {
				JSONArray subCategoryArray  = categoryArray.optJSONArray(i);
				if (subCategoryArray != null && subCategoryArray.length() > 0) {
					String category = subCategoryArray.optString(0);
					if (!TextUtils.isEmpty(category)) {
						categories.add(category.trim());
					}
				}
			}
		}
		else {
			categories = Collections.emptyList();
		}
	}
}
