package com.dimitargenov.yelp.data;

import android.support.annotation.NonNull;
import com.dimitargenov.yelp.data.DataManager.RequestBuilder;
import java.util.Collection;
import rx.Observable;

/**
 *
 * @param <T> type of data models
 * @param <RB> {@link RequestBuilder}-derived type
 * @param <E> collection type (list, map, set) which would hold all {@code T} data models
 * @param <ID> identifier used for memory cache LRU keys and for disk cache storage
 */
public interface DataManager<T, RB extends RequestBuilder, E extends Collection, ID> {
	/**
	 * Marker interface
	 */
	interface RequestBuilder {};

	/**
	 * Initialize the whole chain starting from top to bottom:
	 * <ul>
	 *     <li>memory cache</li>
	 *     <li>disk cache</li>
	 *     <li>remote call</li>
	 * </ul>
	 *
	 * When implementing, will require storing any remote data into the disk cache,
	 * memory cache and then return the result
	 *
	 * @return observable instance
	 */
	@NonNull
	Observable<E> get(ID id);

	/**
	 * Request directly remote data, then caching it into disk cache, memory cache and finally return the result
	 *
	 * @return observable instance
	 */
	@NonNull
	Observable<E> loadAndGet(@NonNull ID id, @NonNull final RB requestBuilder);

	/**
	 * Clear memoryCache
	 */
	void clearMemoryCache();

	/**
	 * Clear disk cache
	 */
	void clearDiskCache();
}
