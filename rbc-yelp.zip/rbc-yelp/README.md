## rbc-yelp
#### Structure
- [app](https://github.com/dimitar71/rbc-yelp/tree/master/app) - application project for phone/tablet devices and orientation UI updates
- [data](https://github.com/dimitar71/rbc-yelp/tree/master/data) - agnostic library project which can be hooked easily to any other UI application project, e.g. Android Wear or TV

#### Requirements
- `Android Studio 1.5.1` and above - tested with both 1.5.1 and 2.0 Preview 8
- `JDK 1.7` and above
- device or emulator with API 17 or above - Android 4.2 and above
